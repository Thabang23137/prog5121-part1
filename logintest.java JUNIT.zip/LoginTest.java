import org.junit.jupiter.api.Test;
import prog5121poe.Login;

public class LoginTest {

    @Test
    public void testUsernameCorrect() {
    }

    @Test
    public void testUsernameIncorrect() {
    }
}